/**
 * 
 */
/**
 * 
 */
module house {
	requires java.desktop;
	requires java.sql;
}