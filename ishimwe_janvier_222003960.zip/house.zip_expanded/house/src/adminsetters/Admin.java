package adminsetters;

public class Admin {

	public void setFname(String text) {
		// TODO Auto-generated method stub
		
	}

	
	}

}
