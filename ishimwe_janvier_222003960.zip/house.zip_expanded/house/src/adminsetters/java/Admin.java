package adminsetters.java;

public class Admin {

}
